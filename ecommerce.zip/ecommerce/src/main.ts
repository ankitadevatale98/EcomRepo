import { AppConstants }from "./constants/app-constants";
import { Role }from "./constants/role";
import { Product }from "./models/Product";

class Startup {
public static main(): void {
let product1: Product = { id: 123, name: 'Axe', category: { id: 101, name: 'Hand Tool' }};
let product2: Product = { id: 122, name: 'Hand Saw', category: { id: 101, name: 'Hand Tool' }};

let products: Product[] = [product1, product2];

// To Iterate over an array
// for (const elem of products) { // Array of type Product
// console.log(elem.name);
// }

// To Interate over properties of object
// for (const prop in product1) {
// console.log(prop);
// }


console.log(AppConstants.APP_NAME);
console.log(Role.SUPER_ADMIN);
console.log(Role['SUPER_ADMIN']);

}
}

Startup.main();