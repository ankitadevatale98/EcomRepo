"use strict";
exports.__esModule = true;
var app_constants_1 = require("./constants/app-constants");
var role_1 = require("./constants/role");
var Startup = /** @class */ (function () {
    function Startup() {
    }
    Startup.main = function () {
        var product1 = { id: 123, name: 'Axe', category: { id: 101, name: 'Hand Tool' } };
        var product2 = { id: 122, name: 'Hand Saw', category: { id: 101, name: 'Hand Tool' } };
        var products = [product1, product2];
        // To Iterate over an array
        // for (const elem of products) { // Array of type Product
        // console.log(elem.name);
        // }
        // To Interate over properties of object
        // for (const prop in product1) {
        // console.log(prop);
        // }
        console.log(app_constants_1.AppConstants.APP_NAME);
        console.log(role_1.Role.SUPER_ADMIN);
        console.log(role_1.Role['SUPER_ADMIN']);
    };
    return Startup;
}());
Startup.main();
