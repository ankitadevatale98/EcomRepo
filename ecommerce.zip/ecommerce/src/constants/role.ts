enum Role  {
    NORMAL = 'Normal User',
    ADMIN = 'Admin',
    SUPER_ADMIN = 'Super Admin User'
} 