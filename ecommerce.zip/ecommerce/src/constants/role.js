var Role;
(function (Role) {
    Role["NORMAL"] = "Normal User";
    Role["ADMIN"] = "Admin";
    Role["SUPER_ADMIN"] = "Super Admin User";
})(Role || (Role = {}));
