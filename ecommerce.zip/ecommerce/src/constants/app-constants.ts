import{AppConstants}

class AppConstants {
    static readonly APP_NAME = 'MY-ECOMMERCE-APP'; 
    
}